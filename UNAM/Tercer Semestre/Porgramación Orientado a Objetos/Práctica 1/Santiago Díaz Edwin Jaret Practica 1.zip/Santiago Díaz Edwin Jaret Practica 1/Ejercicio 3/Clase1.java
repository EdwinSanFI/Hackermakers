class Clase1{

	public static String metodo1(){
		String mensaje = "Programación Orientada a objetos";
		return mensaje;
	}

	public static int metodo2(){
		System.out.println("Programar es arte");
		return 23;
	}


}