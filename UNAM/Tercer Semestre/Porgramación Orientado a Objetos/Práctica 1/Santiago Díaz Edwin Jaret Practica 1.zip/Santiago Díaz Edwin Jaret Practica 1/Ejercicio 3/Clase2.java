public class Clase2{

	public static String metodo1(){
		
		String mensaje = "¿Puedo usar cosas que se encuentren en otros archivos (clases)?";
		return mensaje;

	}

}